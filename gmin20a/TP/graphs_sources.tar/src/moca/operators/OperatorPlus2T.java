package moca.operators;

public interface OperatorPlus2T<A,B> extends OperatorPlus<A,B,B> { };


