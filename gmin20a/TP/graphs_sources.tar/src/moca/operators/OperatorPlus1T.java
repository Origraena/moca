package moca.operators;

public interface OperatorPlus1T<A> extends OperatorPlus<A,A,A> { };

