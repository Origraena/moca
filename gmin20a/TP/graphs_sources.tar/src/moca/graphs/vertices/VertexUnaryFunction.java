package moca.graphs.vertices;

public interface VertexUnaryFunction<A,V> {

	public A exec(Vertex<V> v);

};


