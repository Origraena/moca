package moca.graphs;

public class IllegalConstructionException extends Exception {

	private static final long serialVersionUID = 2011022603L;

};

