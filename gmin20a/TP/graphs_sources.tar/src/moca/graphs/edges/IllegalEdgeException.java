package moca.graphs.edges;

import java.lang.Exception;

public class IllegalEdgeException extends Exception {

};


