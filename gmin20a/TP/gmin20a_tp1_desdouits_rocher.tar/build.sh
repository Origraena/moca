javac -cp graphs.jar Main.java
