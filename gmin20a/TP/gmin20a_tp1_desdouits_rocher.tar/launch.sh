java -cp graphs.jar:./ Main
